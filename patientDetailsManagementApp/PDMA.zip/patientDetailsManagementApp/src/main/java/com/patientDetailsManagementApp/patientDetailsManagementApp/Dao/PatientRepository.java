package com.patientDetailsManagementApp.patientDetailsManagementApp.Dao;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.patientDetailsManagementApp.patientDetailsManagementApp.model.*;



public interface PatientRepository extends JpaRepository<PDMAModel, Integer>{

	//public List<PDMAModel> findAll();
	public String findByPatientID(int patientID);
	
}


