package com.patientDetailsManagementApp.patientDetailsManagementApp.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.patientDetailsManagementApp.patientDetailsManagementApp.model.PDMAModel;
import com.patientDetailsManagementApp.patientDetailsManagementApp.service.PDMAService;

@RestController
@RequestMapping("/spring-data-jpa")
public class PDMAController {
	
	@Autowired
	public PDMAService pDMAService;

	@GetMapping("/getPatients")
	public List<PDMAModel> findPatients(){
		return pDMAService.findPatients();
	}
}
