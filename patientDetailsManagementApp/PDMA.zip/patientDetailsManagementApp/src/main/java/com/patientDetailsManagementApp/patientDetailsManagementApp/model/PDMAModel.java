package com.patientDetailsManagementApp.patientDetailsManagementApp.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PDMAModel {
	

	@Id
	private int patientID;
	
	@Column
	private String patientName;
	
	@Column
	private int patientAge;
	
	@Column
	private String patientProfession;

	public PDMAModel(int patientID, String patientName, int patientAge, String patientProfession) {
		super();
		this.patientID = patientID;
		this.patientName = patientName;
		this.patientAge = patientAge;
		this.patientProfession = patientProfession;
	}

	public PDMAModel() {
		super();
	}	
	
	
	
	
}
