package com.patientDetailsManagementApp.patientDetailsManagementApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientDetailsManagementAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
